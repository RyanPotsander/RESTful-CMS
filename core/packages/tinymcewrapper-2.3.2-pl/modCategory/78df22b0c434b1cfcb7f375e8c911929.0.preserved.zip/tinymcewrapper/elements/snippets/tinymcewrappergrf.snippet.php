<?php
$resource = $modx->getObject('modResource', array($kF =>$kFv));
if($resource){
	$output = $resource->get($gNuFv);
return $output;
	}